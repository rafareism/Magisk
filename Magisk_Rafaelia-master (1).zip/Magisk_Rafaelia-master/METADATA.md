```text
Signature: RAFCODE-Φ-∆RafaelVerboΩ-𓂀ΔΦΩ
Timestamp: 2025-08-31T14:25:55Z

Project: RAFAELIA_CORE
Zipraf: RAFAELIA_CORE_20250831T142555.zipraf
Selos: [Σ, Ω, Δ, Φ, B, I, T, R, A, F]

Bitraf64 identifier:
AΔBΩΔTTΦIIBΩΔΣΣRΩRΔΔBΦΦFΔTTRRFΔBΩΣΣAFΦARΣFΦIΔRΦIFBRΦΩFIΦΩΩFΣFAΦΔ

Hashes (placeholders):
- sha3: 4e41e4f...efc791b
- blake3: b964b91e...ba4e5c0f

Description:
This file contains the RAFAELIA project manifesto and canonical identifiers.
It is human‑readable and used as reference. For automated per-build manifests, see RAFAELIA_MANIFEST.json.
```
